extends Control


var player_state: PlayerState
var game = null
var player_index: int = -1

var cube_scene = preload("res://cube.tscn")

const TROPHY_TOKEN_SIZE = Vector2(56, 56)
# Printed Trophy slot on the Mage card, lower-right circular recess.
const TROPHY_STACK_LOCAL_POSITION = Vector2(272, 116)
const TROPHY_STACK_SIZE = Vector2(58, 70)


# =========================================================
# DIMENSIONI PLAYER BOARD
# =========================================================

const BOARD_SIZE = Vector2(900, 730)
const SHEET_VARIANTS = {
	Color.RED: "mage_sheet_red.png",
	Color.BLUE: "mage_sheet_blue.png",
	Color.GREEN: "mage_sheet_green.png",
	Color.PURPLE: "mage_sheet_purple.png",
	Color.YELLOW: "mage_sheet_yellow.png",
	Color.WHITE: "mage_sheet.png",
}

# Spell Card
const SPELL_SIZE = Vector2(150, 200)

# Mage Card
const MAGE_CARD_SIZE = Vector2(330, 190)

const CARD_GAP = 12.0


# =========================================================
# DAMAGE TRACK
# =========================================================

const DAMAGE_SLOT_SIZE = 24.0
const DAMAGE_SLOT_GAP = 18.0

const DAMAGE_TRACK_POSITION = Vector2(204, 61)

# Adatta solo questo valore se visivamente il cube.tscn
# risulta troppo grande/piccolo.
const DAMAGE_CUBE_SCALE = DAMAGE_SLOT_SIZE / 14.0


# =========================================================
# READY
# =========================================================

func _ready():
	setup_layout()


# =========================================================
# PLAYER SETUP
# =========================================================

func setup(
	player: PlayerState,
	game_node = null,
	index: int = -1
):
	player_state = player
	game = game_node
	player_index = index if index >= 0 else player.player_index

	create_damage_track()
	refresh()


func refresh():
	if player_state == null:
		return
	refresh_sheet_art()

	$PlayerName.text = player_state.player_name

	if player_state.mage.mage_id == "":
		$MageName.text = "Mage: -"
	else:
		$MageName.text = game.mage_school_label(player_index)

	$HealthLabel.text = (
		"HP: "
		+ str(player_state.mage.get_remaining_health())
		+ "/"
		+ str(player_state.mage.health)
	)

	$PowerLabel.text = (
		"Power: "
		+ str(player_state.power)
	)

	$CubeLabel.text = (
		"Cubes: "
		+ str(player_state.available_cubes)
	)

	$HandInfo.text = (
		"Hand: "
		+ str(player_state.get_hand_size())
	)

	refresh_spell_slots()
	refresh_damage_track()
	refresh_quests()
	refresh_action_tokens()
	refresh_evocations()
	refresh_mage_card()
	refresh_trophies()
	refresh_destiny_tokens()
	refresh_transformation()
	$GrimoireSlot/Label.text = "GRIMOIRE\n%d" % player_state.grimoire.size()
	$MemoriesSlot/Label.text = "MEMORIES\n%d" % player_state.memories.size()


# =========================================================
# LAYOUT GENERALE
# =========================================================

func setup_layout():
	size = BOARD_SIZE
	custom_minimum_size = BOARD_SIZE

	setup_background()
	setup_info()
	setup_main_cards()
	setup_deck_slots()


func setup_background():
	$Background.hide()
	if get_node_or_null("SheetArt") == null:
		var art := TextureRect.new()
		art.name = "SheetArt"
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.texture = preload("res://assets/player_boards/mage_sheet.png")
		art.position = Vector2(150, 40)
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		art.size = Vector2(600, 500)
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(art)
		move_child(art, 0)
	refresh_sheet_art()


func refresh_sheet_art() -> void:
	var art := get_node_or_null("SheetArt") as TextureRect
	if art == null or player_state == null:
		return
	var filename: String = SHEET_VARIANTS.get(player_state.color, "mage_sheet.png")
	art.texture = load("res://assets/player_boards/" + filename)


func setup_info():
	var positions := [Vector2(150, 8), Vector2(380, 104), Vector2(290, 8), Vector2(420, 8), Vector2(550, 8)]
	var nodes := [$PlayerName, $MageName, $HealthLabel, $PowerLabel, $CubeLabel]
	for i in range(nodes.size()):
		nodes[i].position = positions[i]
		nodes[i].size = Vector2(150, 24)
		nodes[i].mouse_filter = Control.MOUSE_FILTER_IGNORE
		nodes[i].z_index = 3
	$MageName.visible = false


func setup_main_cards():
	setup_slot($SpellSlots/QuickSpellSlot, Vector2(203, 94), SPELL_SIZE)
	setup_slot($MageCardSlot, Vector2(368, 94), MAGE_CARD_SIZE)
	setup_slot($SpellSlots/SpellSlotI, Vector2(203, 304), SPELL_SIZE)
	setup_slot($SpellSlots/SpellSlotII, Vector2(372, 304), SPELL_SIZE)
	setup_slot($SpellSlots/SpellSlotIII, Vector2(540, 304), SPELL_SIZE)
	_configure_spell_slot($SpellSlots/QuickSpellSlot, "Q")
	_configure_spell_slot($SpellSlots/SpellSlotI, "I")
	_configure_spell_slot($SpellSlots/SpellSlotII, "II")
	_configure_spell_slot($SpellSlots/SpellSlotIII, "III")


func setup_slot(
	slot: Control,
	slot_position: Vector2,
	slot_size: Vector2
):
	slot.add_theme_stylebox_override("panel", StyleBoxEmpty.new())
	slot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	slot.position = slot_position
	slot.size = slot_size
	slot.custom_minimum_size = slot_size

	var label = slot.get_node_or_null("Label")

	if label != null:
		label.position = Vector2.ZERO
		label.size = slot_size

		label.horizontal_alignment = (
			HORIZONTAL_ALIGNMENT_CENTER
		)

		label.vertical_alignment = (
			VERTICAL_ALIGNMENT_CENTER
		)


# =========================================================
# GRIMOIRE / MEMORIES / HAND
# =========================================================

func setup_deck_slots():
	setup_slot($GrimoireSlot, Vector2(12, 320), Vector2(126, 180))
	setup_slot($MemoriesSlot, Vector2(762, 320), Vector2(126, 180))
	for deck in [$GrimoireSlot, $MemoriesSlot]:
		var frame := StyleBoxFlat.new()
		frame.bg_color = Color(0.035, 0.035, 0.045)
		frame.border_color = Color(0.5, 0.48, 0.45)
		frame.set_border_width_all(1)
		frame.set_corner_radius_all(6)
		deck.add_theme_stylebox_override("panel", frame)
		if deck.get_node_or_null("DeckBack") == null:
			var art := TextureRect.new()
			art.name = "DeckBack"
			art.texture = preload("res://assets/tabletop/card_back.png")
			art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			art.mouse_filter = Control.MOUSE_FILTER_IGNORE
			deck.add_child(art)
			art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
			deck.move_child(art, 0)
		var caption: Label = deck.get_node("Label")
		caption.add_theme_color_override("font_outline_color", Color.BLACK)
		caption.add_theme_constant_override("outline_size", 6)
		caption.add_theme_font_size_override("font_size", 14)
		caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if $MemoriesSlot.get_node_or_null("PublicBrowseButton") == null:
		var browse := Button.new()
		browse.name = "PublicBrowseButton"
		browse.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		browse.flat = true
		browse.text = ""
		browse.focus_mode = Control.FOCUS_NONE
		browse.tooltip_text = "View public Memories"
		browse.pressed.connect(_open_public_memories)
		$MemoriesSlot.add_child(browse)
	$HandInfo.position = Vector2(690, 8)
	$HandInfo.size = Vector2(110, 25)


func _open_public_memories() -> void:
	if game == null or game.beta_hud == null:
		return
	game.beta_hud.open_public_memories(player_index)


func _configure_spell_slot(slot: Control, slot_id: String) -> void:
	if slot.get_node_or_null("CardBack") == null:
		var back := ColorRect.new()
		back.name = "CardBack"
		back.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		back.color = Color(0.055, 0.055, 0.07, 1.0)
		back.mouse_filter = Control.MOUSE_FILTER_IGNORE
		back.visible = false
		slot.add_child(back)
		slot.move_child(back, 0)
		var back_art := TextureRect.new()
		back_art.texture = preload("res://assets/tabletop/card_back.png")
		back_art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		back_art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		back_art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		back.add_child(back_art)
		back_art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	if slot.get_node_or_null("CardArt") == null:
		var art := TextureRect.new()
		art.name = "CardArt"
		art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		art.visible = false
		slot.add_child(art)

	if slot.get_node_or_null("CardClickButton") == null:
		var button := Button.new()
		button.name = "CardClickButton"
		button.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		button.flat = true
		button.text = ""
		button.focus_mode = Control.FOCUS_NONE
		button.pressed.connect(
			Callable(self, "_on_spell_slot_pressed").bind(slot_id)
		)
		button.gui_input.connect(func(event: InputEvent):
			if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:
				button.accept_event()
				game.activate_player_board_spell.call_deferred(player_index, slot_id, true))
		slot.add_child(button)


func refresh_spell_slots() -> void:
	if player_state == null:
		return

	_render_spell_slot($SpellSlots/QuickSpellSlot, "Q", "QUICK")
	_render_spell_slot($SpellSlots/SpellSlotI, "I", "I")
	_render_spell_slot($SpellSlots/SpellSlotII, "II", "II")
	_render_spell_slot($SpellSlots/SpellSlotIII, "III", "III")


func _render_spell_slot(
	slot: Control,
	slot_id: String,
	empty_label: String
) -> void:
	_configure_spell_slot(slot, slot_id)

	var label: Label = slot.get_node_or_null("Label")
	var back: ColorRect = slot.get_node_or_null("CardBack")
	var art: TextureRect = slot.get_node_or_null("CardArt")
	var button: Button = slot.get_node_or_null("CardClickButton")

	if label == null or back == null or art == null or button == null:
		return

	var data: Dictionary = {}
	if game != null:
		data = game.get_player_board_spell_slot_data(player_index, slot_id)
	var marker = slot.get_node_or_null("SpellMarker")
	var marker_kind := str(data.get("marker", "")).to_lower()
	if marker != null and marker.get_meta("kind", "") != marker_kind:
		slot.remove_child(marker)
		marker.queue_free()
		marker = null
	if marker == null and not marker_kind.is_empty():
		marker = preload("res://tabletop_style.gd").marker(marker_kind, player_state.color, Vector2(50, 50), slot_id)
		marker.name = "SpellMarker"
		marker.set_meta("kind", marker_kind)
		marker.position = Vector2(50, 77)
		marker.z_index = 2
		slot.add_child(marker)
	var active_side = slot.get_node_or_null("ActiveSide")
	if active_side == null:
		active_side = preload("res://tabletop_style.gd").spell_side_frame()
		active_side.size = Vector2(SPELL_SIZE.x, SPELL_SIZE.y * 0.5)
		slot.add_child(active_side)
	active_side.visible = data.get("public", false)
	# Source PNGs print both halves upright. Highlight the selected half without
	# turning the text upside down when Dark is played.
	active_side.position.y = SPELL_SIZE.y * 0.5 if data.get("use_dark_side", false) else 0.0
	var definition: SpellCardState = game.spell_database.get_spell(str(data.get("id", "")))
	if definition != null and definition.has_single_effect():
		active_side.visible = false

	if data.is_empty():
		back.visible = false
		art.visible = false
		art.texture = null
		label.visible = false
		label.text = empty_label
		button.disabled = true
		button.tooltip_text = ""
		return

	var public_card: bool = bool(data.get("public", false))

	if public_card:
		var texture: Texture2D = SpellArtResolver.get_texture(
			str(data.get("id", "")),
			str(data.get("school_id", ""))
		)

		back.visible = false

		if texture != null:
			art.texture = texture
			art.visible = true
			label.visible = false
		else:
			art.texture = null
			art.visible = false
			label.visible = true
			label.text = str(data.get("name", "Spell"))

		button.disabled = false
		button.tooltip_text = (
			str(data.get("name", "Spell")) + " — right-click to inspect"
		)
		return

	back.visible = true
	art.texture = null
	art.visible = false
	label.visible = marker_kind.is_empty()
	label.text = empty_label + "\nSET"
	label.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	label.add_theme_color_override("font_outline_color", Color.BLACK)
	label.add_theme_constant_override("outline_size", 4)

	var can_inspect: bool = bool(data.get("can_inspect", false))
	button.disabled = not can_inspect
	button.tooltip_text = (
		"Left-click to cast · Right-click to inspect your prepared Spell"
		if can_inspect
		else "Prepared Spell — hidden"
	)


func _on_spell_slot_pressed(slot_id: String) -> void:
	if game == null:
		return
	game.activate_player_board_spell(player_index, slot_id, Input.is_key_pressed(KEY_SHIFT))


func refresh_action_tokens() -> void:
	if game == null or player_state == null:
		return
	var action_names := PackedStringArray(["Explore", "Fight", "Command"])
	for action in player_state.get_transformation_data().get("actions", []):
		action_names.append(str(action.name))
	for i in range(PlayerState.MAX_PHYSICAL_ACTIONS):
		var token = get_node_or_null("PhysicalAction" + str(i))
		if token == null:
			token = Button.new()
			token.name = "PhysicalAction" + str(i)
			token.position = Vector2(385 + i * 70, 215)
			token.size = Vector2(60, 60)
			token.add_theme_font_size_override("font_size", 36)
			token.pressed.connect(game.open_player_board_action.bind(player_index, "physical"))
			add_child(token)
		# Anubis prints the two action recesses at different positions from
		# the other Mage cards. Map their source-art centres into the card slot.
		if player_state.mage.mage_id == "anubis":
			var printed_size := Vector2(1671, 941)
			var art_scale: float = minf(MAGE_CARD_SIZE.x / printed_size.x, MAGE_CARD_SIZE.y / printed_size.y)
			var art_offset: Vector2 = (MAGE_CARD_SIZE - printed_size * art_scale) * 0.5
			var centre := Vector2(233 + i * 334, 698)
			token.position = $MageCardSlot.position + art_offset + centre * art_scale - token.size * 0.5
		else:
			token.position = Vector2(385 + i * 70, 215)
		var available: bool = i < player_state.available_physical_actions
		token.text = "+" if available else "×"
		token.tooltip_text = "Physical action: " + " / ".join(action_names) if available else "Physical action exhausted"
		token.disabled = not available or game.get_player_board_action_options(player_index, "physical").is_empty()
		for state in ["normal", "hover", "pressed", "disabled"]:
			var style := StyleBoxFlat.new()
			style.bg_color = Color(0.04, 0.05, 0.07)
			style.border_color = get_damage_cube_color(player_index)
			style.set_border_width_all(5)
			style.set_corner_radius_all(10)
			if state == "hover":
				style.bg_color = Color(0.18, 0.2, 0.25)
			token.add_theme_stylebox_override(state, style)
		for state in ["font_color", "font_hover_color", "font_pressed_color", "font_disabled_color"]:
			token.add_theme_color_override(state, Color.WHITE if available else Color(1, 0.12, 0.12))
	for i in range(3):
		var category: String = ["momentum", "quests", "finish"][i]
		var button = get_node_or_null("BoardAction_" + category)
		if button == null:
			button = Button.new()
			button.name = "BoardAction_" + category
			button.text = ["Momentum", "Resolve Quest", "End activation"][i]
			button.position = Vector2(203 + i * 169, 695)
			button.size = Vector2(150, 30)
			button.add_theme_font_size_override("font_size", 13)
			button.pressed.connect(game.open_player_board_action.bind(player_index, category))
			add_child(button)
		button.visible = not game.get_player_board_action_request(player_index).is_empty()
		button.disabled = game.get_player_board_action_options(player_index, category).is_empty()
	for slot_id in ["Q", "I", "II", "III"]:
		var slot_path: String = "QuickSpellSlot" if slot_id == "Q" else "SpellSlot" + slot_id
		var button = get_node_or_null("SpellSlots/" + slot_path + "/CardClickButton")
		if button != null and game.get_player_board_cast_token(player_index, slot_id) != "":
			button.tooltip_text = "Click to cast · Shift-click to inspect"


func refresh_quests() -> void:
	if game == null:
		return
	for section in ["revealed", "completed"]:
		var heading = get_node_or_null("QuestHeading_" + section)
		if heading == null:
			heading = Label.new()
			heading.name = "QuestHeading_" + section
			heading.text = "QUESTS" if section == "revealed" else "COMPLETED"
			heading.position = Vector2(12, 40) if section == "revealed" else Vector2(762, 40)
			heading.add_theme_font_size_override("font_size", 12)
			heading.mouse_filter = Control.MOUSE_FILTER_IGNORE
			add_child(heading)
		var strip = get_node_or_null("Quest_" + section)
		if strip == null:
			strip = ScrollContainer.new()
			strip.name = "Quest_" + section
			strip.position = Vector2(12, 65) if section == "revealed" else Vector2(762, 65)
			strip.size = Vector2(126, 235)
			add_child(strip)
		for child in strip.get_children():
			strip.remove_child(child)
			child.queue_free()
		var row := VBoxContainer.new()
		strip.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		strip.add_child(row)
		for data in game.get_player_board_quest_cards(player_index, section):
			var card: Button
			var quest: QuestState = data.get("quest")
			if not data.get("can_inspect", false):
				card = game.ReferenceCardPreview.make_back("Private Quest", Vector2(112, 154), Callable(), game.ReferenceCardPreview.quest_back_texture(quest.get_moon()) if quest != null else null)
			elif quest != null and quest.solved:
				card = game.ReferenceCardPreview.make_back("Solved Quest · Inspect", Vector2(112, 154), game.open_quest_card.bind(quest), game.ReferenceCardPreview.quest_back_texture(quest.get_moon()))
			else:
				card = game.ReferenceCardPreview.make_card("quests", data.id, data.name,
					Vector2(112, 154), game.open_quest_card.bind(data.quest))
			row.add_child(card)
			card.set_meta("choice_quest", quest)
			if quest != null and not quest.solved:
				_render_quest_progress_cubes(card, quest, Vector2(112, 154))
	var counter = get_node_or_null("SolvedQuestCount")
	if counter == null:
		counter = Label.new()
		counter.name = "SolvedQuestCount"
		counter.position = Vector2(762, 302)
		counter.add_theme_font_size_override("font_size", 13)
		counter.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(counter)
	var solved: int = 0
	for quest in player_state.completed_quests:
		if quest.solved:
			solved += 1
	counter.text = "Solved Quests: " + str(solved)
	refresh_jinxes()


func get_display_size() -> Vector2:
	var width := 1180.0 if player_state.transformation != null else 900.0
	if not player_state.mage.jinxes.is_empty(): width += 144.0
	var paired := player_state.evocations.any(func(ev): return ev.assigned_mage >= 0 and game.is_evocation_in_play(ev))
	return Vector2(width, 770 if paired else 730)


func refresh_jinxes() -> void:
	# Assigned Jinxes are public, regardless of the hand/Quest viewer.
	var panel := get_node_or_null("JinxCards") as Control
	if panel == null:
		panel = Control.new()
		panel.name = "JinxCards"
		panel.position = Vector2(906, 40)
		panel.size = Vector2(126, 644)
		panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(panel)
	for child in panel.get_children():
		panel.remove_child(child)
		child.queue_free()
	panel.visible = not player_state.mage.jinxes.is_empty()
	if not panel.visible: return
	var heading := Label.new()
	heading.text = "JINXES"
	heading.add_theme_font_size_override("font_size", 12)
	heading.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(heading)
	var scroll := ScrollContainer.new()
	scroll.name = "Cards"
	scroll.position = Vector2(0, 25)
	scroll.size = Vector2(126, 619)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	scroll.add_child(column)
	for jinx in player_state.mage.jinxes:
		var id: String = str(jinx.id)
		var definition := ForgottenAttachments.definition("jinxes", id)
		var item := VBoxContainer.new()
		item.name = id
		column.add_child(item)
		var card: Button = game.ReferenceCardPreview.make_card("jinxs", id, str(definition.get("name", id)),
			Vector2(112, 154), game.open_jinx_card.bind(player_index, id))
		card.set_meta("jinx_id", id)
		item.add_child(card)
		game.ReferenceCardPreview.add_jinx_progress(card, id, int(jinx.progress), get_damage_cube_color(player_index))


func _render_quest_progress_cubes(card: Control, quest: QuestState, card_size: Vector2) -> void:
	# The Quest artwork already prints every cube slot.  Overlay only the cubes
	# actually placed by the player, left-to-right on the printed slot row.
	var placed: int = mini(quest.progress, quest.get_cube_slots())
	if placed <= 0:
		return
	var overlay := Control.new()
	overlay.name = "QuestProgress"
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_child(overlay)
	var cube_scale: float = card_size.x / 112.0 * 0.82
	var cube_visual: float = 14.0 * cube_scale
	var gap: float = 3.0 * cube_scale
	var total_width: float = placed * cube_visual + maxi(0, placed - 1) * gap
	var start_x: float = (card_size.x - total_width) * 0.5
	# Rebirth Quest cube slots are printed across the central task/reward divider.
	# Keeping this as a proportion makes the overlay line up in both compact and
	# enlarged Hand views without drawing synthetic empty slots over the art.
	var slot_y: float = card_size.y * 0.555 - cube_visual * 0.5
	var printed_centers := preload("res://reference_card_preview.gd").quest_progress_centers(quest.get_id(), card_size)
	for i in range(placed):
		var cube = cube_scene.instantiate()
		cube.cube_color = get_damage_cube_color(player_index)
		cube.scale = Vector2.ONE * cube_scale
		cube.position = Vector2(start_x + i * (cube_visual + gap), slot_y)
		if i < printed_centers.size():
			cube.position = printed_centers[i] - Vector2.ONE * cube_visual * 0.5
		overlay.add_child(cube)


func create_damage_track():
	if player_state == null:
		return

	# Se per qualche motivo setup() venisse richiamato,
	# eliminiamo immediatamente il vecchio track.
	var old_track = get_node_or_null("DamageTrack")

	if old_track != null:
		old_track.free()


	var track = Control.new()

	track.name = "DamageTrack"
	track.position = DAMAGE_TRACK_POSITION

	add_child(track)


	# Una casella per ogni punto Health del Mage.
	for i in range(player_state.mage.health):
		var slot = ColorRect.new()

		slot.name = (
			"DamageSlot_"
			+ str(i)
		)

		slot.position = Vector2(
			i
			* (
				DAMAGE_SLOT_SIZE
				+ DAMAGE_SLOT_GAP
			),
			0
		)

		slot.size = Vector2(
			DAMAGE_SLOT_SIZE,
			DAMAGE_SLOT_SIZE
		)

		# Fondo dello slot vuoto.
		slot.color = Color(
			0.20,
			0.20,
			0.20,
			0.0
		)

		slot.mouse_filter = Control.MOUSE_FILTER_IGNORE

		track.add_child(slot)


func refresh_damage_track():
	if player_state == null:
		return

	var track = get_node_or_null("DamageTrack")

	if track == null:
		return


	var damage_cubes = (
		player_state.mage.damage_cubes
	)
	if game != null and game.table_shell != null:
		damage_cubes = game.table_shell.displayed_damage(player_state.player_index, damage_cubes)
	$HealthLabel.text = "HP: %d/%d" % [maxi(0, player_state.mage.health - damage_cubes.size()), player_state.mage.health]
	# Keep occupied slots' nodes: pending conversion/healing choices are attached
	# to those cubes and must survive unrelated Quest/board refreshes.
	for i in range(track.get_child_count()):
		var slot = track.get_child(i)
		var cube = slot.get_node_or_null("DamageCube")
		if i >= damage_cubes.size():
			if cube != null:
				slot.remove_child(cube)
				cube.queue_free()
			continue
		if cube == null:
			cube = cube_scene.instantiate()
			cube.name = "DamageCube"
			slot.add_child(cube)
		cube.cube_color = get_damage_cube_color(damage_cubes[i])
		cube.queue_redraw()
		# Cube is a Control drawn from its top-left corner.
		cube.position = Vector2.ZERO

		cube.scale = Vector2(
			DAMAGE_CUBE_SCALE,
			DAMAGE_CUBE_SCALE
		)


# =========================================================
# COLORI DAMAGE CUBES
# =========================================================

func get_damage_cube_color(
	owner_id: int
) -> Color:

	# Black Rose
	if owner_id == -1:
		return Color.BLACK
	if game != null and owner_id >= 0 and owner_id < game.players.size():
		return game.players[owner_id].color


	var colors = [
		Color.RED,
		Color.BLUE,
		Color.GREEN,
		Color.PURPLE,
		Color.YELLOW,
		Color.WHITE
	]


	if owner_id >= 0 and owner_id < colors.size():
		return colors[owner_id]


	return Color.GRAY

func refresh_mage_card() -> void:
	var art = $MageCardSlot.get_node_or_null("MageArt")
	if art == null:
		art = TextureRect.new()
		art.name = "MageArt"
		art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		$MageCardSlot.add_child(art)
	art.texture = game.ReferenceCardPreview.card_texture("mages", player_state.mage.mage_id) if game != null else null
	# Existing user-supplied contact sheet: use its original pixels without modifying it.
	if art.texture == null and player_state.mage.mage_id == "rikkart":
		var atlas := AtlasTexture.new()
		atlas.atlas = preload("res://assets/mages/screen_3.png")
		atlas.region = Rect2(1100, 14, 396, 249)
		art.texture = atlas
	$MageCardSlot/Label.visible = art.texture == null
	$MageCardSlot/Label.text = player_state.mage.mage_id.capitalize() + "\nStrength %d · Movement %d" % [player_state.mage.strength, player_state.mage.speed]


func refresh_transformation() -> void:
	var panel := get_node_or_null("TransformationCard") as Control
	if panel == null:
		panel = Control.new()
		panel.name = "TransformationCard"
		panel.position = Vector2(916, 94)
		panel.size = Vector2(250, 370)
		add_child(panel)
		var title := Label.new()
		title.name = "Title"
		title.position = Vector2(0, -34)
		title.size = Vector2(250, 30)
		title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		title.add_theme_font_size_override("font_size", 20)
		title.mouse_filter = Control.MOUSE_FILTER_IGNORE
		panel.add_child(title)
		var art := TextureRect.new()
		art.name = "Art"
		art.size = Vector2(250, 342)
		art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		art.mouse_filter = Control.MOUSE_FILTER_IGNORE
		panel.add_child(art)
		# User PNGs print the transformation upright; retain that readable face.
		var edge := Panel.new()
		edge.position = Vector2(0, 133)
		edge.size = Vector2(250, 209)
		edge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var style := StyleBoxFlat.new()
		style.bg_color = Color(1, 0.86, 0.55, 0.035)
		style.border_color = Color(0.91, 0.78, 0.48, 0.8)
		style.set_border_width_all(2)
		edge.add_theme_stylebox_override("panel", style)
		panel.add_child(edge)
		var button := Button.new()
		button.name = "Inspect"
		button.size = art.size
		button.flat = true
		button.pressed.connect(_inspect_transformation, CONNECT_DEFERRED)
		panel.add_child(button)
	panel.visible = player_state != null and player_state.transformation != null
	panel.position.x = 916 + (144 if player_state != null and not player_state.mage.jinxes.is_empty() else 0)
	if not panel.visible:
		return
	var card: SpellCardState = player_state.transformation.spell
	panel.get_node("Art").texture = game.ReferenceCardPreview.card_texture("spells", card.id)
	panel.get_node("Title").text = player_state.get_transformation_id().capitalize()
	panel.get_node("Inspect").tooltip_text = "Inspect %s · Strength %d" % [player_state.get_transformation_id().capitalize(), player_state.get_mage_strength()]


func _inspect_transformation() -> void:
	if player_state.transformation == null or game == null:
		return
	var card: SpellCardState = player_state.transformation.spell
	game._reference_card_preview().show_card("spells", card.id, player_state.get_transformation_id().capitalize(), "Physical Actions available from your Action tokens.")


func _make_trophy_token(owner_id: int, total_count: int) -> Control:
	var token := preload("res://tabletop_style.gd").marker("trophy_token", get_damage_cube_color(owner_id), TROPHY_TOKEN_SIZE)
	token.mouse_filter = Control.MOUSE_FILTER_PASS
	token.tooltip_text = "Trophies: %d\nTrophy of %s" % [total_count, game.player_display_name(owner_id)]
	return token


func refresh_trophies() -> void:
	var parent: Control = $MageCardSlot
	var stack = parent.get_node_or_null("TrophyStack") as Control
	if stack == null:
		stack = Control.new()
		stack.name = "TrophyStack"
		stack.position = TROPHY_STACK_LOCAL_POSITION
		stack.size = TROPHY_STACK_SIZE
		stack.mouse_filter = Control.MOUSE_FILTER_PASS
		stack.z_index = 30
		parent.add_child(stack)

	for child in stack.get_children():
		stack.remove_child(child)
		child.queue_free()

	stack.tooltip_text = "Trophies: %d" % player_state.trophies.size()
	stack.show()
	var total := player_state.trophies.size()
	# Hover/click also reports zero, without inventing a Trophy in the stack.
	var was_pinned: bool = bool(stack.get_meta("count_pinned", false))
	for i in range(total):
		var owner_id: int = int(player_state.trophies[i])
		var token := _make_trophy_token(owner_id, total)
		# Keep the printed Trophy recess visible while making duplicates read as
		# a physical stack. Newest Trophy sits on top.
		token.position = Vector2(0, maxf(0.0, 12.0 - float(total - 1 - i) * 6.0))
		token.z_index = 20 + i
		stack.add_child(token)

	var count_badge := Label.new()
	count_badge.name = "TrophyCountBadge"
	count_badge.text = "%d trophies" % total
	count_badge.position = Vector2(-18, -30)
	count_badge.size = Vector2(90, 24)
	count_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	count_badge.add_theme_font_size_override("font_size", 14)
	count_badge.add_theme_color_override("font_color", Color.WHITE)
	count_badge.add_theme_color_override("font_outline_color", Color.BLACK)
	count_badge.add_theme_constant_override("outline_size", 5)
	count_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	count_badge.z_index = 2001
	count_badge.visible = was_pinned
	stack.add_child(count_badge)
	var hover := Button.new()
	hover.name = "TrophyCountHitbox"
	hover.position = Vector2(-6, -6)
	hover.size = stack.size + Vector2(12, 12)
	hover.flat = true
	hover.text = ""
	hover.focus_mode = Control.FOCUS_NONE
	hover.tooltip_text = "%d trophies" % total
	hover.z_index = 2000
	hover.mouse_entered.connect(func(): count_badge.show())
	hover.mouse_exited.connect(func():
		if not bool(stack.get_meta("count_pinned", false)):
			count_badge.hide())
	hover.pressed.connect(func():
		var pinned := not bool(stack.get_meta("count_pinned", false))
		stack.set_meta("count_pinned", pinned)
		count_badge.visible = pinned)
	stack.add_child(hover)


func refresh_destiny_tokens() -> void:
	var row = get_node_or_null("DestinyTokens")
	if row == null:
		row = Control.new()
		row.name = "DestinyTokens"
		# Keep Destiny clearly above the two Physical Action tokens.
		row.position = Vector2(385, 168)
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(row)
	for child in row.get_children():
		row.remove_child(child)
		child.queue_free()
	for i in range(player_state.mage.destiny_tokens.size()):
		var owner: int = player_state.mage.destiny_tokens[i]
		var token := TextureRect.new()
		token.texture = game.ReferenceCardPreview.card_texture("tokens", "destiny")
		token.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		token.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		token.position = Vector2(i * 44, 0)
		token.size = Vector2(42, 42)
		token.tooltip_text = "Destiny — assigned by " + game.player_display_name(owner)
		row.add_child(token)
		var cube = cube_scene.instantiate()
		cube.cube_color = get_damage_cube_color(owner)
		token.add_child(cube)
		cube.scale = Vector2(0.7, 0.7)
		cube.position = Vector2(28, 27)
	for i in player_state.mage.infectio_tokens.size():
		var owner: int = player_state.mage.infectio_tokens[i]
		var token := Panel.new()
		token.position = Vector2(i * 34, 46)
		token.size = Vector2(30, 30)
		token.tooltip_text = "Infectio — assigned by " + game.player_display_name(owner)
		row.add_child(token)
		var cube = cube_scene.instantiate()
		cube.cube_color = get_damage_cube_color(owner)
		token.add_child(cube)
		cube.position = Vector2(15, 15)


func refresh_evocations() -> void:
	if game == null or player_state == null:
		return
	var row = get_node_or_null("EvocationCards")
	if row == null:
		row = Control.new()
		row.name = "EvocationCards"
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(row)
	for child in row.get_children():
		row.remove_child(child)
		child.queue_free()
	var attachments := ScrollContainer.new()
	attachments.name = "AssignedCards"
	attachments.position = Vector2(762, 525)
	attachments.size = Vector2(126, 159)
	attachments.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	row.add_child(attachments)
	var attached_list := VBoxContainer.new()
	attached_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	attachments.add_child(attached_list)
	for evocation in player_state.evocations:
		if not game.is_evocation_in_play(evocation):
			continue
		if bool(evocation.definition.get("no_slot", false)):
			var nightmare := Button.new()
			nightmare.text = "%s\nSlot %d · HP %s" % [evocation.evocation_name, evocation.assigned_slot,
				"∞" if not ForgottenEvocations.ability(game, evocation, "immune_damage").is_empty() else str(evocation.get_remaining_health())]
			if bool(evocation.definition.get("no_slot", false)):
				nightmare.text = "%s\nHP %d · %s" % [evocation.evocation_name, evocation.get_remaining_health(), evocation.room_id.replace("_", " ")]
			nightmare.custom_minimum_size = Vector2(110, 50)
			nightmare.add_theme_font_size_override("font_size", 14)
			nightmare.pressed.connect(game.open_evocation_inspection.bind(evocation, true))
			nightmare.set_meta("evocation", evocation)
			attached_list.add_child(nightmare)
			continue
		var card = game.ReferenceCardPreview.make_card("evocations", evocation.evocation_id,
			evocation.get_display_name(), Vector2(164, 110), game.open_evocation_inspection.bind(evocation, true))
		var assigned: bool = evocation.assigned_mage >= 0
		var slot: int = evocation.assigned_slot if assigned else evocation.board_number
		var paired := player_state.evocations.any(func(ev): return ev.assigned_mage >= 0 and ev.assigned_slot == slot and game.is_evocation_in_play(ev))
		card.name = ("AssignedEvocationSlot" if assigned else "EvocationSlot") + str(slot)
		# The Nightmare shares the numbered slot; it never occupies a fourth slot.
		card.position = Vector2(196 + (slot - 1) * 169, 636 if assigned else (508 if paired else 552))
		card.set_meta("evocation", evocation)
		row.add_child(card)
		if FamiliarRules.is_familiar(evocation):
			var action := Button.new()
			action.name = "FamiliarAction"
			action.position = Vector2(100, 67)
			action.size = Vector2(60, 38)
			action.text = "+" if evocation.familiar_action_available else "×"
			action.add_theme_font_size_override("font_size", 24)
			action.tooltip_text = "%s · Familiar Action · %s" % [evocation.evocation_name,"Guard" if evocation.familiar_guard else "Hunt"]
			action.disabled = not evocation.familiar_action_available or game.get_player_board_action_options(player_index,"familiar").is_empty()
			action.pressed.connect(game.open_player_board_action.bind(player_index,"familiar"))
			card.add_child(action)
		# Board choices can arrive in the same frame as a network refresh.
		# Lay out each cube now so its hitbox has its final position immediately.
		var damage := Control.new()
		damage.name = "EvocationDamage"
		damage.position = Vector2(4, 4)
		damage.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(damage)
		for i in evocation.damage_cubes.size():
			var cube = cube_scene.instantiate()
			cube.cube_color = get_damage_cube_color(evocation.damage_cubes[i])
			cube.position = Vector2((i % 9) * 18, floori(i / 9.0) * 18)
			damage.add_child(cube)
		var label := Label.new()
		label.position = Vector2(4, 111)
		label.text = "#%d · HP %d/%d · P%d" % [evocation.board_number, evocation.get_remaining_health(), evocation.health, game.get_evocation_controller_id(evocation) + 1]
		if assigned: label.text = "Slot %s · Umbra · HP %d/%d" % [["I", "II", "III"][slot - 1], evocation.get_remaining_health(), evocation.health]
		label.add_theme_font_size_override("font_size", 12)
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(label)
		for index in evocation.upgrades.size():
			var id: String = evocation.upgrades[index]
			var data := ForgottenAttachments.definition("upgrades", id)
			var upgrade = game.ReferenceCardPreview.make_card("upgrades", id,
				str(data.get("name", id)), Vector2(68, 44), _inspect_upgrade.bind(evocation, id))
			upgrade.name = "Upgrade_" + id
			upgrade.position = Vector2(92 - index * 25, 62)
			upgrade.tooltip_text = str(data.get("name", id)) + " → " + evocation.get_display_name()
			card.add_child(upgrade)
	attachments.visible = attached_list.get_child_count() > 0


func _inspect_upgrade(evocation: EvocationState, id: String) -> void:
	if not game.is_evocation_in_play(evocation) or not evocation.upgrades.has(id):
		return
	var data := ForgottenAttachments.definition("upgrades", id)
	game._reference_card_preview().show_card("upgrades", id, str(data.get("name", id)),
		"Assigned to " + evocation.get_display_name() + " · " + game.player_display_name(evocation.owner_id))
