class_name EvocationState
extends RefCounted


var evocation_id: String = ""
var evocation_name: String = ""
var archetype: String = ""
# Reference to the existing EvocationDatabase definition (also rebuilt on clients).
var definition: Dictionary = {}

var owner_id: int = -1
var controller_id: int = -1
var board_number: int = 0
var assigned_mage: int = -1
var assigned_slot: int = 0
var familiar_guard: bool = false
var familiar_action_available: bool = true
var upgrades: Array[String] = []
var stored_trophies: Array[int] = []

var health: int = 0
var strength: int = 0
var speed: int = 0

var room_id: String = ""

var damage_cubes: Array[int] = []


func _init(
	id: String,
	name: String,
	evocation_archetype: String,
	evocation_health: int,
	evocation_strength: int,
	evocation_speed: int,
	owner: int
):
	evocation_id = id
	evocation_name = name
	archetype = evocation_archetype

	health = evocation_health
	strength = evocation_strength
	speed = evocation_speed

	owner_id = owner
	controller_id = owner


func get_damage() -> int:
	return damage_cubes.size()


func has_archetype(kind: String) -> bool:
	return archetype == kind or kind in definition.get("additional_archetypes",[])


func get_display_name() -> String:
	return evocation_name + (" #" + str(board_number) if board_number > 0 else "")


func get_remaining_health() -> int:
	return health - get_damage()


func is_defeated() -> bool:
	# Jack cannot be defeated while its card still holds any Trophy.
	var immortal: bool = definition.get("abilities", []).any(func(a): return a.get("type") == "immortal_while_trophies")
	return get_damage() >= health and (not immortal or stored_trophies.is_empty())


func add_damage(owner: int, amount: int) -> int:
	var amount_to_place = min(
		max(amount, 0),
		get_remaining_health()
	)

	for i in range(amount_to_place):
		damage_cubes.append(owner)

	return amount_to_place


func get_damage_from(owner: int) -> int:
	return damage_cubes.count(owner)
